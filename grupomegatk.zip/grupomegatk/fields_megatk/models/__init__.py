# -*- coding: utf-8 -*-

from . import sale_order
from . import purchase_order
from . import product
from . import res_partner
from . import helpdesk
from . import account_invoice
from . import stock_picking